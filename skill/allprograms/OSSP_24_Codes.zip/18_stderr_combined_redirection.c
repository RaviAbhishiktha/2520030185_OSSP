/*
18 - stderr redirection and combined stdout+stderr.
Compile: gcc 18_stderr_combined_redirection.c -o p18
Run: ./p18 output.txt
*/
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(int argc,char **argv) {
    if(argc!=2){fprintf(stderr,"Usage: %s file\n",argv[0]);return 1;}

    int fd=open(argv[1],O_WRONLY|O_CREAT|O_TRUNC,0644);
    if(fd<0){perror("open");return 1;}

    pid_t p=fork();
    if(p==0){
        dup2(fd,STDOUT_FILENO);
        dup2(fd,STDERR_FILENO);
        close(fd);
        execlp("sh","sh","-c","echo stdout-message; echo stderr-message >&2",(char*)NULL);
        _exit(127);
    }
    close(fd);
    waitpid(p,NULL,0);
    return 0;
}
