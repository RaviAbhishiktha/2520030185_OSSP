/*
09 - Environment variable expansion.
Examples: echo $HOME, echo $USER
Compile: gcc 09_variable_expansion.c -o p9
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(void) {
    char line[512], out[1024];
    printf("Input: ");
    if (!fgets(line, sizeof(line), stdin)) return 0;

    size_t oi = 0;
    for (size_t i = 0; line[i] && oi + 1 < sizeof(out); ) {
        if (line[i] == '$') {
            i++;
            char name[128];
            size_t ni = 0;
            while ((isalnum((unsigned char)line[i]) || line[i] == '_') &&
                   ni + 1 < sizeof(name))
                name[ni++] = line[i++];
            name[ni] = '\0';

            const char *v = getenv(name);
            if (v) {
                size_t len = strlen(v);
                if (oi + len < sizeof(out)) {
                    memcpy(out + oi, v, len);
                    oi += len;
                }
            }
        } else {
            out[oi++] = line[i++];
        }
    }
    out[oi] = '\0';
    printf("Expanded: %s", out);
    return 0;
}
