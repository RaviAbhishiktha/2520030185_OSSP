/*
17 - Output (>) and append (>>) redirection.
Compile: gcc 17_output_append_redirection.c -o p17
Run: ./p17 file [append]
*/
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(int argc,char **argv) {
    if(argc<2 || argc>3){fprintf(stderr,"Usage: %s file [append]\n",argv[0]);return 1;}

    int flags=O_WRONLY|O_CREAT|(argc==3 ? O_APPEND : O_TRUNC);
    int fd=open(argv[1],flags,0644);
    if(fd<0){perror("open");return 1;}

    pid_t p=fork();
    if(p==0){
        dup2(fd,STDOUT_FILENO);
        close(fd);
        execlp("echo","echo","Output from OSSP redirection",(char*)NULL);
        _exit(127);
    }
    close(fd);
    waitpid(p,NULL,0);
    return 0;
}
