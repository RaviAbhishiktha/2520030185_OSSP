/*
06 - Escaped spaces/special characters and program execution.
Example: ./p6 echo hello\ world
Compile: gcc 06_escape_exec.c -o p6
*/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

#define MAXARGS 32

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s program [args...]\n", argv[0]);
        return 1;
    }

    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }

    if (pid == 0) {
        execvp(argv[1], &argv[1]);
        perror("execvp");
        _exit(127);
    }

    int status;
    waitpid(pid, &status, 0);
    if (WIFEXITED(status))
        printf("Child exit status: %d\n", WEXITSTATUS(status));
    return 0;
}
