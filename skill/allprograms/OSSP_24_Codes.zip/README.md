# OSSP — 24 C Programs

These 24 standalone programs are based directly on the 24 numbered skill/problem
items in the uploaded OSSP Skill Content Delivery Concepts document.

## Build
```bash
make
```

Or compile one file:
```bash
gcc -Wall -Wextra -std=c11 01_process_fork_exec.c -o p1
```

## Notes
- Programs 1–23 demonstrate individual OS/shell concepts.
- Program 24 is an integration/test-runner example.
- Run on Linux/WSL because the programs use POSIX system calls.
- For memory checking:
```bash
valgrind --leak-check=full --track-origins=yes ./p3
```

The source document lists 24 numbered items and topics such as fork/exec,
interactive input, history, parsing/quotes/escapes, waitpid, PATH lookup,
variables, built-ins, cd/pwd/export, pipelines, redirection, background jobs,
signals, process groups, testing, Valgrind and documentation.
