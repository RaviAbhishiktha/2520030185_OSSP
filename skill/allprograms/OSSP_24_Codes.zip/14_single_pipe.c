/*
14 - One pipeline: producer | consumer.
Compile: gcc 14_single_pipe.c -o p14
*/
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(void) {
    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    pid_t a=fork();
    if(a<0) return 1;
    if(a==0) {
        dup2(fd[1],STDOUT_FILENO);
        close(fd[0]); close(fd[1]);
        execlp("printf","printf","apple\nbanana\ncherry\n",(char*)NULL);
        perror("printf"); _exit(127);
    }

    pid_t b=fork();
    if(b<0) return 1;
    if(b==0) {
        dup2(fd[0],STDIN_FILENO);
        close(fd[0]); close(fd[1]);
        execlp("wc","wc","-l",(char*)NULL);
        perror("wc"); _exit(127);
    }

    close(fd[0]); close(fd[1]);
    waitpid(a,NULL,0);
    waitpid(b,NULL,0);
    return 0;
}
