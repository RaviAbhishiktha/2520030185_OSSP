/*
15 - Multiple pipeline stages: printf | grep | wc.
Compile: gcc 15_multiple_pipes.c -o p15
*/
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(void) {
    int p1[2], p2[2];
    pipe(p1); pipe(p2);

    pid_t a=fork();
    if(a==0) {
        dup2(p1[1],STDOUT_FILENO);
        close(p1[0]); close(p1[1]); close(p2[0]); close(p2[1]);
        execlp("printf","printf","red\nblue\ngreen\nred\n",(char*)NULL);
        _exit(127);
    }

    pid_t b=fork();
    if(b==0) {
        dup2(p1[0],STDIN_FILENO);
        dup2(p2[1],STDOUT_FILENO);
        close(p1[0]); close(p1[1]); close(p2[0]); close(p2[1]);
        execlp("grep","grep","red",(char*)NULL);
        _exit(127);
    }

    pid_t c=fork();
    if(c==0) {
        dup2(p2[0],STDIN_FILENO);
        close(p1[0]); close(p1[1]); close(p2[0]); close(p2[1]);
        execlp("wc","wc","-l",(char*)NULL);
        _exit(127);
    }

    close(p1[0]); close(p1[1]); close(p2[0]); close(p2[1]);
    waitpid(a,NULL,0); waitpid(b,NULL,0); waitpid(c,NULL,0);
    return 0;
}
