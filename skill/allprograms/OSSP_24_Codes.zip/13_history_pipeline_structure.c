/*
13 - History buffer and pipeline structure parsing.
Compile: gcc 13_history_pipeline_structure.c -o p13
*/
#include <stdio.h>
#include <string.h>

#define MAX 32

int main(void) {
    char line[1024];
    char *cmd[MAX];
    int n;

    printf("Enter pipeline: ");
    if (!fgets(line,sizeof line,stdin)) return 0;

    n=0;
    char *p=strtok(line,"|\n");
    while(p && n<MAX) {
        while(*p==' '||*p=='\t') p++;
        cmd[n++]=p;
        p=strtok(NULL,"|\n");
    }

    printf("Pipeline contains %d command(s):\n",n);
    for(int i=0;i<n;i++) printf("Stage %d: %s\n",i+1,cmd[i]);

    return 0;
}
