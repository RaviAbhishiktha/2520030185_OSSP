/*
04 - Tokenization and simple syntax validation.
Compile: gcc 04_lexer_parser.c -o p4
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAXTOK 32

int main(void) {
    char line[512];
    char *tok[MAXTOK];
    int n;

    printf("Enter a command: ");
    if (!fgets(line, sizeof(line), stdin)) return 0;

    n = 0;
    char *p = strtok(line, " \t\r\n");
    while (p && n < MAXTOK) {
        tok[n++] = p;
        p = strtok(NULL, " \t\r\n");
    }

    if (n == 0) {
        puts("Empty command");
        return 0;
    }

    puts("Tokens:");
    for (int i = 0; i < n; ++i)
        printf("[%d] %s\n", i, tok[i]);

    puts("Parser result: token stream accepted");
    return 0;
}
