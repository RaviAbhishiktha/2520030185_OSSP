/*
03 - Command history with dynamically allocated storage.
Compile: gcc 03_history_dynamic_memory.c -o p3
Test with: hello, world, history, exit
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_HISTORY 20

int main(void) {
    char **history = NULL;
    size_t count = 0, capacity = 0;
    char line[256];

    while (1) {
        printf("ossh> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = '\0';

        if (!strcmp(line, "exit")) break;

        if (!strcmp(line, "history")) {
            for (size_t i = 0; i < count; ++i)
                printf("%zu  %s\n", i + 1, history[i]);
            continue;
        }

        if (!line[0]) continue;

        if (count == capacity) {
            size_t newcap = capacity ? capacity * 2 : 4;
            if (newcap > MAX_HISTORY) newcap = MAX_HISTORY;
            char **tmp = realloc(history, newcap * sizeof(*history));
            if (!tmp) {
                perror("realloc");
                break;
            }
            history = tmp;
            capacity = newcap;
        }

        if (count < MAX_HISTORY) {
            history[count] = malloc(strlen(line) + 1);
            if (!history[count]) {
                perror("malloc");
                break;
            }
            strcpy(history[count++], line);
        }
    }

    for (size_t i = 0; i < count; ++i) free(history[i]);
    free(history);
    return 0;
}
