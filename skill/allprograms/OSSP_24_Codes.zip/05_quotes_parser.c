/*
05 - Single and double quotes.
Single quotes preserve literal text; double quotes preserve spaces.
This compact parser keeps quote characters out of the token values.
*/
#include <stdio.h>
#include <string.h>

#define MAXTOK 32
#define MAXLEN 512

int main(void) {
    char line[MAXLEN], token[MAXLEN];
    int nt = 0, ti = 0;
    char quote = 0;

    printf("ossh> ");
    if (!fgets(line, sizeof(line), stdin)) return 0;

    for (size_t i = 0; ; ++i) {
        char c = line[i];

        if (quote) {
            if (c == quote) quote = 0;
            else token[ti++] = c;
        } else if (c == '\'' || c == '"') {
            quote = c;
        } else if (c == ' ' || c == '\t' || c == '\n' || c == '\0') {
            if (ti) {
                token[ti] = '\0';
                printf("TOKEN %d: %s\n", nt++, token);
                ti = 0;
            }
            if (c == '\0' || c == '\n') break;
        } else {
            token[ti++] = c;
        }
    }

    if (quote) fprintf(stderr, "Syntax error: unmatched quote\n");
    return 0;
}
