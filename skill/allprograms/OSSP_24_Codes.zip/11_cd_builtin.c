/*
11 - cd built-in and previous-directory support.
Commands: cd DIR, cd -, cd
Compile: gcc 11_cd_builtin.c -o p11
*/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <limits.h>

int main(void) {
    char line[512], old[PATH_MAX], cur[PATH_MAX];
    old[0] = '\0';

    while (1) {
        if (getcwd(cur,sizeof cur)) printf("ossh:%s> ",cur);
        else printf("ossh> ");
        fflush(stdout);

        if (!fgets(line,sizeof line,stdin)) break;
        line[strcspn(line,"\n")] = 0;

        if (!strcmp(line,"exit")) break;

        if (!strncmp(line,"cd",2) && (line[2]==' ' || line[2]=='\0')) {
            char *dir = line + 2;
            while (*dir==' ') dir++;
            if (!*dir) dir = getenv("HOME");

            if (!strcmp(dir,"-")) {
                if (!old[0]) { puts("cd: OLDPWD not set"); continue; }
                dir = old;
            }

            if (!getcwd(cur,sizeof cur)) { perror("getcwd"); continue; }
            if (chdir(dir) == -1) { perror("cd"); continue; }
            strcpy(old,cur);
        } else {
            puts("Only cd and exit are implemented in this demo.");
        }
    }
    return 0;
}
