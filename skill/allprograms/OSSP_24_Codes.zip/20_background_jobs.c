/*
20 - Background jobs, job table, monitoring.
Compile: gcc 20_background_jobs.c -o p20
Commands: sleep 5 &, jobs, exit
*/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

#define MAXJ 32
struct job { int id; pid_t pid; int active; };
struct job jobs[MAXJ];
int next_id=1;

void check_jobs(void) {
    for(int i=0;i<MAXJ;i++) if(jobs[i].active) {
        int st; pid_t r=waitpid(jobs[i].pid,&st,WNOHANG);
        if(r>0){ printf("[%d] Done pid=%d\n",jobs[i].id,r); jobs[i].active=0; }
    }
}

int main(void) {
    char line[256];
    while(1) {
        check_jobs();
        printf("ossh> "); fflush(stdout);
        if(!fgets(line,sizeof line,stdin)) break;
        line[strcspn(line,"\n")]=0;
        if(!strcmp(line,"exit")) break;

        if(!strcmp(line,"jobs")){
            for(int i=0;i<MAXJ;i++) if(jobs[i].active)
                printf("[%d] Running pid=%d\n",jobs[i].id,jobs[i].pid);
            continue;
        }

        size_t len=strlen(line);
        int bg=(len>0 && line[len-1]=='&');
        if(bg) line[len-1]=0;

        pid_t p=fork();
        if(p==0){ execlp("sh","sh","-c",line,(char*)NULL); perror("exec"); _exit(127); }

        if(bg) {
            for(int i=0;i<MAXJ;i++) if(!jobs[i].active){
                jobs[i]=(struct job){next_id++,p,1}; break;
            }
        } else waitpid(p,NULL,0);
    }
    return 0;
}
