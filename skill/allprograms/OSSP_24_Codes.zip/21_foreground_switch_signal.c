/*
21 - Foreground switching concept using process groups and terminal control.
Run on a real Linux terminal. Ctrl-Z and SIGCONT can be observed.
Compile: gcc 21_foreground_switch_signal.c -o p21
*/
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(void) {
    pid_t shell=getpid(), child=fork();
    if(child<0){perror("fork");return 1;}

    if(child==0){
        setpgid(0,0);
        execlp("sleep","sleep","20",(char*)NULL);
        _exit(127);
    }

    setpgid(child,child);
    printf("Started foreground job pid=%d. Waiting...\n",child);

    int status;
    waitpid(child,&status,WUNTRACED);

    if(WIFSTOPPED(status)) {
        printf("Job stopped. Sending SIGCONT...\n");
        kill(-child,SIGCONT);
        waitpid(child,&status,0);
    }

    tcsetpgrp(STDIN_FILENO,shell);
    printf("Foreground job finished.\n");
    return 0;
}
