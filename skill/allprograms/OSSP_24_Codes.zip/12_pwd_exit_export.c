/*
12 - pwd, exit cleanup, and export built-in.
Compile: gcc 12_pwd_exit_export.c -o p12
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <ctype.h>

int valid_name(const char *s) {
    if (!s || (!isalpha((unsigned char)*s) && *s!='_')) return 0;
    for (const char *p=s+1; *p; ++p)
        if (!isalnum((unsigned char)*p) && *p!='_') return 0;
    return 1;
}

int main(void) {
    char line[512], cwd[PATH_MAX];

    while (1) {
        printf("ossh> "); fflush(stdout);
        if (!fgets(line,sizeof line,stdin)) break;
        line[strcspn(line,"\n")] = 0;

        if (!strcmp(line,"exit")) {
            puts("Cleaning up shell state...");
            break;
        } else if (!strcmp(line,"pwd")) {
            if (getcwd(cwd,sizeof cwd)) puts(cwd);
            else perror("pwd");
        } else if (!strncmp(line,"export ",7)) {
            char *x = line+7;
            char *eq = strchr(x,'=');
            if (!eq) { puts("Usage: export NAME=value"); continue; }
            *eq = 0;
            if (!valid_name(x)) { puts("Invalid variable name"); continue; }
            if (setenv(x,eq+1,1) == -1) perror("setenv");
        } else {
            puts("Supported: pwd, export NAME=value, exit");
        }
    }
    return 0;
}
