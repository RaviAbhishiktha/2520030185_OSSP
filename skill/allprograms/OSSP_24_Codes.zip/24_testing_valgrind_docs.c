/*
24 - Integration-style test runner for the OSSP shell components.
This problem combines validation, test execution, cleanup and documentation
of the final deliverable. It launches selected programs and reports status.

Compile: gcc 24_testing_valgrind_docs.c -o p24
Run from the directory containing p1, p2, p7 and p14:
./p24

For memory checking, use:
valgrind --leak-check=full ./p3
*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int run_test(const char *program) {
    pid_t p=fork();
    if(p<0){perror("fork");return 0;}
    if(p==0){
        execl(program,program,(char*)NULL);
        perror(program);
        _exit(127);
    }
    int st;
    waitpid(p,&st,0);
    if(WIFEXITED(st) && WEXITSTATUS(st)==0){
        printf("[PASS] %s\n",program);
        return 1;
    }
    printf("[FAIL] %s\n",program);
    return 0;
}

int main(void) {
    const char *tests[]={"./p1","./p2","./p7","./p14"};
    int total=sizeof(tests)/sizeof(tests[0]), passed=0;

    puts("OSSP integration test runner");
    puts("----------------------------");
    for(int i=0;i<total;i++) passed += run_test(tests[i]);

    printf("Result: %d/%d tests passed\n",passed,total);
    puts("Documentation checklist:");
    puts("1. Architecture and process flow documented");
    puts("2. Syscalls identified");
    puts("3. Build and test commands recorded");
    puts("4. Valgrind cleanup verified where applicable");
    puts("5. README and repository structure reviewed");

    return passed==total ? 0 : 1;
}
