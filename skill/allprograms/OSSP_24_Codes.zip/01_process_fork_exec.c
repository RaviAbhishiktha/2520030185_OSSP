/*
01 - Process abstraction: fork(), exec(), parent-child relationship.
Compile: gcc 01_process_fork_exec.c -o p1
Run: ./p1
*/
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(void) {
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        printf("Child: PID=%d PPID=%d\n", getpid(), getppid());
        execlp("echo", "echo", "Child executed a new program", (char *)NULL);
        perror("exec");
        _exit(127);
    }

    printf("Parent: PID=%d created child PID=%d\n", getpid(), pid);
    waitpid(pid, NULL, 0);
    printf("Parent: child finished\n");
    return 0;
}
