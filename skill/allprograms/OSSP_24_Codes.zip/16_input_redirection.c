/*
16 - Input redirection: command < file.
Compile: gcc 16_input_redirection.c -o p16
Run: ./p16 filename
*/
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(int argc,char **argv) {
    if(argc!=2){fprintf(stderr,"Usage: %s file\n",argv[0]);return 1;}
    int fd=open(argv[1],O_RDONLY);
    if(fd<0){perror("open");return 1;}

    pid_t p=fork();
    if(p==0){
        dup2(fd,STDIN_FILENO);
        close(fd);
        execlp("wc","wc","-l",(char*)NULL);
        perror("exec"); _exit(127);
    }
    close(fd);
    waitpid(p,NULL,0);
    return 0;
}
