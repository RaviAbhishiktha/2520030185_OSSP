/*
07 - Child-process synchronization and monitoring using waitpid().
Compile: gcc 07_waitpid.c -o p7
*/
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(void) {
    pid_t p = fork();
    if (p < 0) { perror("fork"); return 1; }

    if (p == 0) {
        printf("Child %d working...\n", getpid());
        sleep(2);
        _exit(42);
    }

    int status;
    pid_t r = waitpid(p, &status, 0);
    if (r == -1) { perror("waitpid"); return 1; }

    if (WIFEXITED(status))
        printf("Child %d exited with %d\n", r, WEXITSTATUS(status));
    else if (WIFSIGNALED(status))
        printf("Child killed by signal %d\n", WTERMSIG(status));

    return 0;
}
