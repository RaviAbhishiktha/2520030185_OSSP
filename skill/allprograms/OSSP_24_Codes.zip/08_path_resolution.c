/*
08 - PATH lookup for an executable.
Compile: gcc 08_path_resolution.c -o p8
*/
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s command\n", argv[0]);
        return 1;
    }

    if (strchr(argv[1], '/')) {
        if (access(argv[1], X_OK) == 0) {
            printf("Executable: %s\n", argv[1]);
            return 0;
        }
        perror(argv[1]);
        return 1;
    }

    const char *path = getenv("PATH");
    if (!path) return 1;

    char *copy = strdup(path);
    if (!copy) return 1;

    for (char *d = strtok(copy, ":"); d; d = strtok(NULL, ":")) {
        char full[1024];
        snprintf(full, sizeof(full), "%s/%s", d, argv[1]);
        if (access(full, X_OK) == 0) {
            printf("%s\n", full);
            free(copy);
            return 0;
        }
    }

    printf("Command not found: %s\n", argv[1]);
    free(copy);
    return 127;
}
