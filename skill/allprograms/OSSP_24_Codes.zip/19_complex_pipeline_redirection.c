/*
19 - Combined pipeline and redirection: cat file | grep word > output.
Compile: gcc 19_complex_pipeline_redirection.c -o p19
Run: ./p19 input.txt output.txt word
*/
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(int argc,char **argv) {
    if(argc!=4){fprintf(stderr,"Usage: %s input output word\n",argv[0]);return 1;}

    int in=open(argv[1],O_RDONLY);
    int out=open(argv[2],O_WRONLY|O_CREAT|O_TRUNC,0644);
    if(in<0||out<0){perror("file");return 1;}

    int pipefd[2]; pipe(pipefd);

    pid_t a=fork();
    if(a==0){
        dup2(in,STDIN_FILENO); dup2(pipefd[1],STDOUT_FILENO);
        close(in); close(out); close(pipefd[0]); close(pipefd[1]);
        execlp("cat","cat",(char*)NULL); _exit(127);
    }

    pid_t b=fork();
    if(b==0){
        dup2(pipefd[0],STDIN_FILENO); dup2(out,STDOUT_FILENO);
        close(in); close(out); close(pipefd[0]); close(pipefd[1]);
        execlp("grep","grep",argv[3],(char*)NULL); _exit(127);
    }

    close(in); close(out); close(pipefd[0]); close(pipefd[1]);
    waitpid(a,NULL,0); waitpid(b,NULL,0);
    return 0;
}
