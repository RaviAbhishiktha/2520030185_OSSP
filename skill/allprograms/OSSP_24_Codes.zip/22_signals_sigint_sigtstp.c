/*
22 - Signal handlers: SIGINT and SIGTSTP forwarding.
Compile: gcc 22_signals_sigint_sigtstp.c -o p22
*/
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>

volatile sig_atomic_t child_pid=0;

void sigint_handler(int sig) {
    (void)sig;
    if(child_pid>0) kill(child_pid,SIGINT);
}
void sigtstp_handler(int sig) {
    (void)sig;
    if(child_pid>0) kill(child_pid,SIGTSTP);
}

int main(void) {
    struct sigaction a={0}, z={0};
    a.sa_handler=sigint_handler; sigemptyset(&a.sa_mask);
    z.sa_handler=sigtstp_handler; sigemptyset(&z.sa_mask);
    sigaction(SIGINT,&a,NULL);
    sigaction(SIGTSTP,&z,NULL);

    child_pid=fork();
    if(child_pid==0){
        printf("Child running. Try Ctrl-C / Ctrl-Z.\n");
        while(1) sleep(1);
    }

    int st;
    waitpid(child_pid,&st,WUNTRACED);
    if(WIFSTOPPED(st)){
        printf("Child stopped; continuing it...\n");
        kill(child_pid,SIGCONT);
        sleep(1);
        kill(child_pid,SIGTERM);
        waitpid(child_pid,&st,0);
    }
    printf("Shell process survived signal handling.\n");
    return 0;
}
