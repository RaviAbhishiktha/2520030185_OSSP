/*
02 - Main loop, prompt, keyboard input, backspace, Enter and exit.
Compile: gcc 02_interactive_input_loop.c -o p2
*/
#include <stdio.h>
#include <string.h>

int main(void) {
    char buf[256];

    while (1) {
        printf("ossh> ");
        fflush(stdout);

        if (!fgets(buf, sizeof(buf), stdin))
            break;

        buf[strcspn(buf, "\n")] = '\0';

        if (strcmp(buf, "exit") == 0)
            break;

        if (buf[0] == '\0')
            continue;

        printf("You entered: %s\n", buf);
    }
    return 0;
}
