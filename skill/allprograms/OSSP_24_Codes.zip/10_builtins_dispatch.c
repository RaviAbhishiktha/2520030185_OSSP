/*
10 - Built-in command dispatch table.
Built-ins are executed inside the shell process.
Compile: gcc 10_builtins_dispatch.c -o p10
*/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

typedef void (*handler)(char *);

void do_pwd(char *arg) { (void)arg; char p[1024]; if (getcwd(p,sizeof p)) puts(p); }
void do_help(char *arg) { (void)arg; puts("Built-ins: pwd, help, exit"); }

struct builtin { const char *name; handler fn; };

int main(void) {
    struct builtin table[] = {
        {"pwd", do_pwd},
        {"help", do_help},
        {NULL, NULL}
    };
    char line[256];

    while (1) {
        printf("ossh> "); fflush(stdout);
        if (!fgets(line,sizeof line,stdin)) break;
        line[strcspn(line,"\n")] = 0;
        if (!strcmp(line,"exit")) break;

        int found = 0;
        for (int i=0; table[i].name; ++i)
            if (!strcmp(line,table[i].name)) {
                table[i].fn(NULL);
                found = 1;
                break;
            }
        if (!found) printf("Unknown built-in: %s\n", line);
    }
    return 0;
}
