/*
23 - Process groups and terminal ownership.
Compile: gcc 23_process_groups_terminal.c -o p23
*/
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(void) {
    pid_t shell=getpid();
    pid_t child=fork();

    if(child<0){perror("fork");return 1;}

    if(child==0){
        setpgid(0,0);
        printf("Child PID=%d PGID=%d\n",getpid(),getpgrp());
        sleep(2);
        _exit(0);
    }

    setpgid(child,child);
    printf("Shell PID=%d PGID=%d; child PGID=%d\n",
           shell,getpgrp(),getpgid(child));

    if (isatty(STDIN_FILENO)) {
        if (tcsetpgrp(STDIN_FILENO, child) == -1) perror("tcsetpgrp");
        printf("Terminal handed to child process group.\n");
        waitpid(child,NULL,0);
        if (tcsetpgrp(STDIN_FILENO, getpgrp()) == -1) perror("tcsetpgrp");
        printf("Terminal returned to shell.\n");
    } else {
        waitpid(child,NULL,0);
        puts("No controlling terminal detected.");
    }
    return 0;
}
